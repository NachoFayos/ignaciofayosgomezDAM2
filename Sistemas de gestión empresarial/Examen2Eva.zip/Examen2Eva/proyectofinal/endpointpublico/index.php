<?php

header("Access-Control-Allow-Origin: *"); 
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type, Authorization"); 
?>

<?php

//////// ACTIVACIÓN DE ERRORES

ini_set('display_errors', 1);																								
	ini_set('display_startup_errors', 1);																				
	
$mysqli = mysqli_connect("localhost", "bat1leer", "bat1leer", "bat1");

$peticion = "SELECT * FROM productos";

$resultado = mysqli_query($mysqli, $peticion);

$json = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $json[] = $fila;
}
$json = json_encode($json, JSON_PRETTY_PRINT);
echo $json;

?>