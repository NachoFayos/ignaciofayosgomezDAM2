<?php

$filePath = 'inc/blacklist.txt';   // Ruta al archivo de texto que contiene las direcciones IP


$userIP = $_SERVER['REMOTE_ADDR'];  // Obtener la dirección IP del usuario


if (file_exists($filePath) && is_readable($filePath)) {  // Abrir el archivo para lectura
    $file = fopen($filePath, 'r');

    if ($file) {
        $found = false;

        
        while (($line = fgets($file)) !== false) {  // Leer el archivo línea por línea
            
            $ipFromFile = trim($line);  // Eliminar espacios en blanco y saltos de línea de la línea

            
            if ($ipFromFile === $userIP) {  // Comprobar si la IP coincide
                $found = true;
                break;
            }
        }

        
        fclose($file);  // Cerrar el archivo

        
        if ($found) {  // Si la IP se encuentra, crear el archivo lock.txt
            $lockFile = 'lock.txt';
            if (file_put_contents($lockFile, "IP coincidente: $userIP") !== false) {
               // echo "Tu IP ($userIP) está en la lista. Se ha creado 'lock.txt'.";
            } else {
               // echo "Tu IP ($userIP) está en la lista, pero no se pudo crear 'lock.txt'.";
            }
        } else {
          //  echo "Tu IP ($userIP) no está en la lista.";
        }
    } else {
       // echo "No se pudo abrir el archivo.";
    }
} else {
   // echo "El archivo no existe o no es legible.";
}
?>
