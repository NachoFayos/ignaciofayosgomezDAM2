//////// POBLAR CONTENIDO TABLA ////////
 
function pueblaTabla(datos,campoclave,tabla,listadepartamentos){
    let contenidotabla = document.querySelector("section table tbody")      // Contenido vacío
   contenidotabla.innerHTML = ""                                            // La tabla se vacía por si acaso
   datos.forEach(function(registro){                                       
       let clave_primaria;
       let nuevafila = document.createElement("tr")                        
       Object.keys(registro).forEach(clave => {                            // Fórmula para recorrer correctamente las propiedades de un objeto
           if(clave == campoclave){                                        // Si es clave primaria, la guardaremos como identificador
               clave_primaria = registro[clave]                            
           }
           let nuevacolumna = document.createElement("td")                 
           nuevacolumna.textContent = registro[clave]                      
           nuevacolumna.setAttribute("tabla",tabla)									
           nuevacolumna.setAttribute("columna",clave)
           nuevacolumna.setAttribute("Identificador",clave_primaria)
           nuevacolumna.ondblclick = function(){										// Comportamiento de cuando hago doble click en la celda
               console.log("Has hecho click en una celda")
               this.setAttribute("contenteditable","true")
               this.focus()
           }
           nuevacolumna.onblur = function(){											// Comportamiento de cuando salgo de la celda
               this.setAttribute("contenteditable","false")
               let mensaje = {
                   "tabla":this.getAttribute("tabla"),
                   "columna":this.getAttribute("columna"),
                   "Identificador":this.getAttribute("Identificador"),
                   "valor":this.textContent
               }																					
               fetch("../../servidor/?o=actualizar", {							// Petición para pasar el objeto
                     method: 'POST', 
                     headers: {
                       'Content-Type': 'application/json', 
                     },
                     body: JSON.stringify(mensaje), 
                   })
                 .then(response => {
                    return response.json();                                                       
                 })
                 .then(datos => {
                     console.log(datos)
                 })
               console.log(mensaje)
           }
           nuevafila.appendChild(nuevacolumna)                             
           
       })
       if(listadepartamentos.length > 0){												// Determinamos si hay departamentos 
       
           let columnadepartamentos = document.createElement("td")				
           let selector = document.createElement("select")							
           let opcion = document.createElement("option")							
           opcion.textContent = "Selecciona una opcion"								
           selector.appendChild(opcion)													
           listadepartamentos.forEach(function(departamento){							
               let opcion = document.createElement("option")						
               opcion.textContent = departamento											
               opcion.value = departamento													
               selector.appendChild(opcion)												
           })
           selector.onchange = function(){										
            let seleccion = this.value;                                                   // Opción seleccionada (ficha_de_cliente o historico_de_compra)
            console.log("Voy a cargar la opción:", seleccion, "para el ID:", clave_primaria);
        
            let seccion = document.querySelector("section");
            seccion.innerHTML = `<iframe src="apps/${tabla}/${seleccion}/index.html?id=${clave_primaria}" frameborder="0" width="100%" height="100%"></iframe>`;
        }
        
           columnadepartamentos.appendChild(selector) 								// Se añade el select en la columna
           nuevafila.appendChild(columnadepartamentos) 								
       }
       
       
       let nuevacolumna = document.createElement("td")                     
       nuevacolumna.innerHTML = `
           <span class='boton botonrojo'>✘</span>
       
           `                                     
       nuevacolumna.setAttribute("claveprimaria",clave_primaria)           // Atributo en forma de clave primaria
       nuevafila.appendChild(nuevacolumna)                                 
       nuevacolumna.onclick = function(){                                  
           console.log("Vamos a eliminar algo")                            
           let identificador = this.getAttribute("claveprimaria")          
           fetch("../../servidor/?o=eliminar&tabla="+tabla+"&id="+identificador)     
           this.parentElement.remove()                                     // Eliminar elemento visualmente también
       }
       
       nuevacolumna = document.createElement("td")                     
       nuevacolumna.innerHTML = `
       
           <span class='boton botonrojo'>📑</span>
           `                                     
       nuevacolumna.setAttribute("claveprimaria",clave_primaria)           
       nuevafila.appendChild(nuevacolumna)                                 
       nuevacolumna.onclick = function(){                                  
              

           let identificador = this.getAttribute("claveprimaria")          
           console.log("quiero un informe",tabla,identificador)
           fetch("../../servidor/?o=informe&tabla="+tabla+"&id="+identificador)     
                   .then(function(result){
                       return result.json()
                   })
                   .then(function(datos){
                       console.log(datos)
                       document.querySelector("section").innerHTML = ""
                       document.querySelector("section").innerHTML = renderTable(datos[0])
                   })
       }
       contenidotabla.appendChild(nuevafila)                               
   })
               
}
//////// POBLAR CONTENIDO TABLA ////////