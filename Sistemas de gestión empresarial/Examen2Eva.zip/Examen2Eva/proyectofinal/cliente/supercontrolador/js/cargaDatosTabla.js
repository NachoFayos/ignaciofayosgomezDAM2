
function cargaDatosTabla(tabla){
	console.log("la tabla que voy a coger es:".tabla );

	////////////// APPS ///////////// 

	listadepartamentos = []     ////// FUTURO: Resolver porque departamentos es APPS
	console.log("Las Apps son:",departamentos)
	try{
		departamentos.forEach(function(departamento){
			if(departamento.entidad == tabla){
				console.log("Si que hay archivos, y son:",departamento.departamentos)
				listadepartamentos = departamento.departamentos;
			}
		})
	}catch(Error){
		console.log("Ha habido un error:",Error)
	}
	
	////////////// APPS /////////////


   /////////////////////////////////// LISTADO DE COLUMNAS DE TABLA /////////////////////////////////////////////
   let campoclave; 

   /////// FUTURO: Crear aquí una estructura IF donde si existe la tabla ok pero sino creala ejecutando toda la operación

   document.querySelector("table").style.display = "table"
    fetch("../../servidor/?o=columnastabla&tabla="+tabla)                 
        .then(response => {
          return response.json();                                           
        })
        .then(datos => {
            columnas_tabla = []                                                             // Vaciado de las columnas existentes a la hora de cargar el contenido
            tipos_tabla = []																
            claves_tabla = []																
            campos_busqueda = []															
            let cabeceras_tabla = document.querySelector("table thead tr"); 
            cabeceras_tabla.innerHTML = ""                                                  // Vaciado de la cabecera tablas
            datos.forEach(function(dato){                                   
                let elemento = document.createElement("th")                 
                columnas_tabla.push(dato['Field'])                          
                 
                elemento.textContent = dato['Field']                        
                campos_busqueda.push(document.createElement("input"))											
                campos_busqueda[campos_busqueda.length-1].setAttribute("placeholder",dato['Field'] )	
                
                claves_tabla.push(dato['Key'])										        // Al array de claves se le añade el valor de la clave que viene de la base de datos
                
                campos_busqueda[campos_busqueda.length-1].setAttribute("type",convierteTipoDato(dato['Type']) )
                tipos_tabla.push(convierteTipoDato(dato['Type']))
                
                elemento.appendChild(campos_busqueda[campos_busqueda.length-1])											
                cabeceras_tabla.appendChild(elemento)                       
                if(dato['Key'] == "PRI"){                                   // Si es clave primaria
                    campoclave = dato['Field']                              // Entonces recuerda el nombre del campo
                }
            })
            
            
            if(listadepartamentos.length > 0){                              // Si hay departamentos cargalos
            	let elemento = document.createElement("th")
            	elemento.textContent = "Apps"
            	cabeceras_tabla.appendChild(elemento)
            }
            
            //////// ESTRUCTURA Y CONTENIDO DE LA TABLA ////////

            let elemento = document.createElement("th") 							
            elemento.innerHTML = "<span class='boton botonblanco'>🔎</span>"					
            cabeceras_tabla.appendChild(elemento) 									
            elemento.onclick = function(){	         // Evento de la lupa-botón										

            	mensaje = {}																// Creo un objeto vacio
            	campos_busqueda.forEach(function(campo){							        // Para cada uno de los input de busqueda
            		let columna = campo.getAttribute("placeholder")				
            		let valor = campo.value												
            		if(valor != ""){														
            			mensaje[columna] = valor										
            		}
            	})
            	fetch("../../servidor/?o=buscarSimilar&tabla="+tabla, {		                 // Petición al servidor y se le pasa el objeto
                          method: 'POST', 
                          headers: {
                            'Content-Type': 'application/json', 
                          },
                          body: JSON.stringify(mensaje), 
                        })
					  .then(response => {
						 return response.json();                                                       
					  })
					  .then(datos => {			  
					  		pueblaTabla(datos,campoclave,tabla,listadepartamentos)									
					  })
            }
            //console.log(columnas_tabla);
            
            //////// ESTRUCTURA ////////

            //////// COLUMNAS ////////


                let coleccioncampos = []                                                                // Creo una colección vacía de campos
                let contiene_modal = document.querySelector("#contienemodal")                           // Selecciono el contenedor del modal
                contiene_modal.innerHTML = "<h1>Formulario de inserción: "+tabla+"</h1>"                // Si el modal contenía algo, lo vaćio
                let seccion = document.createElement("section")
                columnas_tabla.forEach(function(columna,index){                                               
                    let contenedor = document.createElement("div")
                    let texto = document.createElement("p")
                    texto.textContent = "Inserta un nuevo elemento para: "+columna+""
                    contenedor.appendChild(texto)
                    if(claves_tabla[index] != "MUL"){
                    	if(tipos_tabla[index] == "textarea"){
                    		coleccioncampos.push(document.createElement("textarea"))
                    	}else{
                    	
		                 coleccioncampos.push(document.createElement("input"))
		                 }                               
		                 coleccioncampos[coleccioncampos.length-1].setAttribute("type",tipos_tabla[index]) 
		                                                          
		                coleccioncampos[coleccioncampos.length-1].setAttribute("placeholder",columna)                                                  
                    	contenedor.appendChild(coleccioncampos[coleccioncampos.length-1])                                                                            
                    
                    }else{
                    		let selectElement = document.createElement("select");
                    coleccioncampos.push(selectElement);

                    let defaultOption = document.createElement("option");
                    defaultOption.textContent = "Selecciona una opción:";
                    selectElement.appendChild(defaultOption);

                    fetchOptionsForSelect(selectElement, columna);
                    selectElement.setAttribute("placeholder", columna);
                    
                    contenedor.appendChild(selectElement);
                    selectjv(selectElement)
                    }  
                     
                    /*
                    try{
                    	
                    }catch(Error){
                    	console.log("no aplica")
                    }
                    */
                    seccion.appendChild(contenedor)           // Añadimos modal
                		
                	})
                contiene_modal.appendChild(seccion) 
                
                let boton_enviar = document.createElement("button")                                     
                boton_enviar.textContent = "Enviar"                                                     
                boton_enviar.onclick = function() {
						 console.log("Vamos a procesar el formulario");
						 console.log(coleccioncampos);
						 //let formData = new FormData();
							
						 let jsonObject = {};           //JSON directamente
							coleccioncampos.forEach(function(campo) {
								 if (campo.getAttribute('placeholder') !== "Identificador") {
									  if (campo.getAttribute('type') === "file") {
											console.log("Archivos no soportados en esta versión.");
									  } else {
											jsonObject[campo.getAttribute('placeholder')] = campo.value;
									  }
								 }
							});

							console.log("Objeto JSON enviado:", jsonObject);

							fetch("../../servidor/?o=insertar&tabla=" + tabla, {
								 method: 'POST',
								 headers: {
									  'Content-Type': 'application/json',
								 },
								 body: JSON.stringify(jsonObject),
							})
								 .then(response => response.text())
								 .then(datos => {
									  console.log(datos);
									  document.querySelector("#modal").classList.remove("aparece");
									  document.querySelector("#modal").classList.add("desaparece");
									  setTimeout(() => {
											document.querySelector("#modal").style.display = "none";
									  }, 1000);
								 });
					};
                contienemodal.appendChild(boton_enviar)                                                 
            
            //////// COLUMNAS ////////
            
            //////// CONTENIDO TABLA ////////
 
            fetch("../../servidor/?o=tabla&tabla="+tabla)                            // Lista de tablas + parámetro
                .then(response => {
                  return response.json();                                                   
                })
                .then(datos => {
                    pueblaTabla(datos,campoclave,tabla,listadepartamentos)
                })
           
            //////// CONTENIDO TABLA ////////
 
        })
    
 }

 function fetchOptionsForSelect(selectElement, column) {                             // Cargar dinámicamente las tablas
    fetch("../../servidor/?o=tabla&tabla=" + column.split("_")[0])
        .then(response => response.json())
        .then(datos => {
            datos.forEach(function(dato) {
                let option = document.createElement("option");
                option.value = dato['Identificador'];
                option.textContent = Object.values(dato).join(' - ');
                selectElement.appendChild(option);
            });
        });
}