<header>
      <h1><img src="../img/logobat.png"></h1>
      <div class="titulotabla">
          <h5>BAT</h5>
          <!--<p>En esta tabla podremos insertar a los clientes</p>-->
        </div>
        <div class="accesibilidad">
        </div>
        <button id="logoutButton">Cerrar sesión</button>
      <nav>
        <div class="botonescabecera">
        <button class="botonimprimir" id="imprimir">🖨️</button>
      	<button class="botonmail" id="mail">📧</button>
      	<button class="botonayuda" id="ayuda">❔</button>
        </div>
      </nav>
</header>
<script><?php echo file_get_contents("modulos/cabecera/cabecera.js");?></script>
<style><?php echo file_get_contents("modulos/cabecera/cabecera.css");?></style>