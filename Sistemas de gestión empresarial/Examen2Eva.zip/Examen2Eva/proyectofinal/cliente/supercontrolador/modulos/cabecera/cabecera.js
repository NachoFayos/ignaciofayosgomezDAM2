/*
	En este archivo encontramos las siguientes funciones:
	1.-Función de imprimir
	2.-Mostrar el panel de lógica de negocio
	3.-Mostrar la ayuda
	4.-Recargar la web al pulsar en el título
*/

function imprimir(){
	/////IMPRIMIR ///////
	
	document.querySelector("#imprimir").onclick = function(){
		window.print()
	}
}


/*function ayuda(){
	/// AYUDA ////////
	
	document.querySelector("#ayuda").onclick = function(){
		console.log("vamos a la ayuda")
		let marco = document.createElement("iframe")
		marco.setAttribute("src","ayuda/")
		document.querySelector("main").appendChild(marco)
	}
}*/
function ayuda() {
    document.querySelector("#ayuda").onclick = function() {
        console.log("Alternar ayuda");
		
        // Verifica si ya existe un iframe abierto
        let marcoExistente = document.querySelector("main iframe");

        if (marcoExistente) {
            // Si el iframe ya está abierto, lo elimina (cerrar ventana)
            marcoExistente.remove();
            console.log("Cerrando ayuda");
        } else {
            // Si no existe, crea y añade el iframe (abrir ventana)
            let marco = document.createElement("iframe")
			marco.setAttribute("src","ayuda/")
            document.querySelector("main").appendChild(marco)
            console.log("Abriendo ayuda");
        }
    };
}
function recargarEnTitulo(){
	/// RECARGAR PAGINA
	document.querySelector("h1").onclick = function(){
		window.location = window.location
	}
}
function abrirEmail(){

	document.querySelector("#mail").onclick = function(){
        console.log("Abriendo el editor de correo...");
	document.querySelector("section").innerHTML = ""
			document.querySelector("section").style.display = "block"
			let marco = document.createElement("iframe")
			marco.setAttribute("src","http://127.0.0.1:5000/")
			document.querySelector("section").appendChild(marco)
	}
}

///////////////////////////////// AMPLIADOR ///////////////////////////////////

document.addEventListener("DOMContentLoaded", function () {
    // Recuperar configuraciones previas del usuario
    let tamanio = localStorage.getItem("tamanioFuente") ? parseFloat(localStorage.getItem("tamanioFuente")) : 1;
    let cantidadContraste = localStorage.getItem("cantidadContraste") ? parseFloat(localStorage.getItem("cantidadContraste")) : 1;
    let invertido = localStorage.getItem("invertido") === "true";
    let fuenteSeleccionada = localStorage.getItem("fuenteSeleccionada") || "Sans-serif";
    let modoOscuro = localStorage.getItem("modoOscuro") === "true";

    // Aplicar configuraciones guardadas
    document.body.style.fontSize = tamanio + "em";
    document.body.style.filter = invertido ? "invert(1) hue-rotate(180deg)" : "invert(0) hue-rotate(0deg)";
    document.body.style.fontFamily = fuenteSeleccionada;
    if (modoOscuro) document.body.classList.add("modo-oscuro");

    // Contenedor de la herramienta
    let contenedor = document.createElement("div");
    contenedor.classList.add("accesibilidad");

    ////////////////// AUMENTAR /////////////////
    let aumentar = document.createElement("button");
    aumentar.textContent = "+";
    aumentar.setAttribute("aria-label", "Ampliar");
    contenedor.appendChild(aumentar);
    aumentar.onclick = function () {
        tamanio *= 1.1;
        document.body.style.fontSize = tamanio + "em";
        localStorage.setItem("tamanioFuente", tamanio);
    };

    ////////////////// DISMINUIR /////////////////
    let disminuir = document.createElement("button");
    disminuir.textContent = "-";
    disminuir.setAttribute("aria-label", "Disminuir");
    contenedor.appendChild(disminuir);
    disminuir.onclick = function () {
        tamanio *= 0.9;
        document.body.style.fontSize = tamanio + "em";
        localStorage.setItem("tamanioFuente", tamanio);
    };

    ////////////////// CONTRASTE /////////////////
    let contraste = document.createElement("button");
    contraste.textContent = "C";
    contraste.setAttribute("aria-label", "Contraste");
    contenedor.appendChild(contraste);
    contraste.onclick = function () {
        cantidadContraste = cantidadContraste === 1 ? 3 : 1; // Alternar entre 1 y 3
        document.body.style.filter = "contrast(" + cantidadContraste + ")";
        localStorage.setItem("cantidadContraste", cantidadContraste);
    };

    ////////////////// INVERTIR /////////////////
    let invertir = document.createElement("button");
    invertir.textContent = "I";
    invertir.setAttribute("aria-label", "Invertir");
    contenedor.appendChild(invertir);
    invertir.onclick = function () {
        invertido = !invertido;
        document.body.style.filter = invertido ? "invert(1) hue-rotate(180deg)" : "invert(0) hue-rotate(0deg)";
        localStorage.setItem("invertido", invertido);
    };

    ////////////////// CAMBIO DE FUENTE /////////////////
    let fuentes = ["Sans-serif", "serif", "Arial", "monospace"];
    let contador = fuentes.indexOf(fuenteSeleccionada);
    if (contador === -1) contador = 0;

    let fuente = document.createElement("button");
    fuente.textContent = "F";
    fuente.setAttribute("aria-label", "Cambiar la fuente");
    contenedor.appendChild(fuente);
    fuente.onclick = function () {
        contador = (contador + 1) % fuentes.length;
        document.body.style.fontFamily = fuentes[contador];
        localStorage.setItem("fuenteSeleccionada", fuentes[contador]);
    };

    ////////////////// MODO OSCURO 🌙 /////////////////
    let botonOscuro = document.createElement("button");
    botonOscuro.innerHTML = "🌙";
    botonOscuro.setAttribute("aria-label", "Modo Oscuro");
    contenedor.appendChild(botonOscuro);
    botonOscuro.onclick = function () {
        document.body.classList.add("modo-oscuro");
        localStorage.setItem("modoOscuro", "true");
    };

    ////////////////// MODO CLARO ☀ /////////////////
    let botonClaro = document.createElement("button");
    botonClaro.innerHTML = "☀";
    botonClaro.setAttribute("aria-label", "Modo Claro");
    contenedor.appendChild(botonClaro);
    botonClaro.onclick = function () {
        document.body.classList.remove("modo-oscuro");
        localStorage.setItem("modoOscuro", "false");
    };

    ////////////////// RESET ⟳ /////////////////
    let reset = document.createElement("button");
    reset.textContent = "⟳";
    reset.setAttribute("aria-label", "Restablecer configuración");
    contenedor.appendChild(reset);
    reset.onclick = function () {
        localStorage.clear();
        location.reload(); // Recarga la página para restablecer los valores por defecto
    };

    document.body.appendChild(contenedor);
});


        document.getElementById("logoutButton").addEventListener("click", function() {
            // Elimina el token de autenticación almacenado (si existe)
            localStorage.removeItem("token");
            sessionStorage.removeItem("token");

            // Opcional: Limpiar otras variables de sesión
            // localStorage.clear();
            // sessionStorage.clear();

            // Redirigir al usuario a la página de login
            window.location.href = "http://localhost:8080/GitHub/Segundo/sistemasgestionempresarial/proyecto/pruebasmodelo157/cliente"; // Cambia esto a la URL de tu login
        });
   