<div id="modal">
   <div id="contienemodal"></div>
 </div>    <!-- Es una ventana emergente que podemos usar para lo que queramos -->
    
<script><?php echo file_get_contents("modulos/modal/modal.js");?></script>
<style><?php echo file_get_contents("modulos/modal/modal.css");?></style>