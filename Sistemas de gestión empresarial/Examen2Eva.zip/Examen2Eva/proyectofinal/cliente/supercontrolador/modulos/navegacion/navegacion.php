<nav>
      	<ul>
      	<h4>Aplicaciones</h4>
      		<li id="businessanalytics"><span class='boton botonblanco'>🤖</span> Business Analytics </li>
      	</ul>
        <ul id="tabla">
          <h4>Tablas</h4>
        </ul>
        
        <ul id="coleccion">
        <h4>Documentos</h4>
        </ul>
        <ul>
        <li id="botonvueltaescritorio2">
            <span class='boton botonblanco'>🔙</span> Volver al escritorio
        </li>
        </ul>
      </nav>
      
       <script><?php echo file_get_contents("modulos/navegacion/navegacion.js");?></script>
<style><?php echo file_get_contents("modulos/navegacion/navegacion.css");?></style>