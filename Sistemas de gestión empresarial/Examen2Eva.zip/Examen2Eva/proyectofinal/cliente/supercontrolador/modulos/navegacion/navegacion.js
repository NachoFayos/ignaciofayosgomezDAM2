function listadoTablas(departamento){
	/////////////////////////////////// LISTADO DE TABLAS /////////////////////////////////////////////
    //console.log("y yo soy el dpto", departamento)
    fetch("../../servidor/?o=listatablasdepartamentos&departamentos="+departamento)                        // LLamo a un microservicio que me da la lista de tablas
        .then(response => {
          return response.json();                                   // Quiero que el servidor me devuelva un json
        })
        .then(datos => {
          //console.log("Aqui voy a vomitar los datos")
        console.log("Las tablas cargan correctamente y son:", datos)
        		poblarMenuNavegacion(datos,"tabla");
        })
    
    /////////////////////////////////// LISTADO DE TABLAS /////////////////////////////////////////////
}

function listadoDocumentos(){
	/////////////////////////////////// LISTADO DE COLECCIONES DE MONGO /////////////////////////////////////////////
    
    fetch("../../servidor/?o=listacolecciones")                        // LLamo a un microservicio que me da la lista de tablas
        .then(response => {
          return response.json();                                   // Quiero que el servidor me devuelva un json
        })
        .then(datos => {
        console.log("Vamos con las colecciones")
        console.log(datos)
        		poblarMenuNavegacion(datos,"coleccion");
        })
    
    /////////////////////////////////// LISTADO DE COLECCIONES DE MONGO /////////////////////////////////////////////
}

// Detectar el evento cuando el DOM haya cargado
document.addEventListener("DOMContentLoaded", function () {
  let botonVolver = document.getElementById("botonvueltaescritorio2");
  if (botonVolver) {
      botonVolver.addEventListener("click", function () {
        window.location.href = "http://localhost:8080/GitHub/Segundo/sistemasgestionempresarial/proyecto/pruebasmodelo157/cliente/escritorio2";
      });
  }
});
