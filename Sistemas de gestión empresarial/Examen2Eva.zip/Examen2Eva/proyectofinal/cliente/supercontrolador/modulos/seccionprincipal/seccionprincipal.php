<section>
      	<div class="consola"><span id="businessanalytics"></span></div> <!-- Candidato para modulo -->
        <button id="insertar">+</button>
        <table>
          <thead>
            <tr>  
            </tr>
          </thead>
          <tbody> 
          </tbody>
        </table>
      </section>
       <script><?php echo file_get_contents("modulos/seccionprincipal/seccionprincipal.js");?></script>
       <script src="./lib/JVGrafica/JVGrafica.js"></script>
<style><?php echo file_get_contents("modulos/seccionprincipal/seccionprincipal.css");?></style> 