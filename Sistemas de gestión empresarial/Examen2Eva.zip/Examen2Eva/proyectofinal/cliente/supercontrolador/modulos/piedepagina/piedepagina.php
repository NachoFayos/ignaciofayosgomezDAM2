
<!--<button class="botontop" id="botontop"></button>-->
<footer>(c) BAT</footer>


<script><?php echo file_get_contents("modulos/piedepagina/piedepagina.js");?></script>
<style><?php echo file_get_contents("modulos/piedepagina/piedepagina.css");?></style> 