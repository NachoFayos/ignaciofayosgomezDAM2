var columnas_tabla = []                                             // Creo una variable global para almacenar las columnas
var departamentos;


window.onload = function(){
	 let aplicacion = localStorage.getItem("bat1_aplicacion")
     let departamento = localStorage.getItem("bat1_departamento")
     
    
    let departamentos = departamento ? departamento : "";        // Aseguramos que departamento tenga un valor válido
    console.log("Departamento actual:", departamentos)

    listadoTablas(departamentos);

    listadoDocumentos();

    cargaGraficas();

    modal()

    abrirEmail()
    
    cargoDepartamentos()

	imprimir();
	
	muestraBI()
	
	ayuda()
     
	recargarEnTitulo()
}


 
 
 
 