<style>
	a{display:block;}
	body{
		font-family:sans-serif;
	}
	pre{
		color:white;
		background:black;
		padding:20px;
		border-radius:10px;
	}
</style>
<?php

function creaIndice($folderPath) {
    if (!is_dir($folderPath)) {
        //die("La carpeta no existe: $folderPath");
    }

    // Función auxiliar para escanear carpetas de forma recursiva
    function scanDirRecursively2($path) {
        $items = scandir($path);
        foreach ($items as $item) {
            // Omitir los punteros de directorio actuales y padres
            if ($item === '.' || $item === '..') {
                continue;
            }

            $fullPath = $path . DIRECTORY_SEPARATOR . $item;
            if (is_dir($fullPath)) {
                echo "<a href='#".$fullPath."'>" . $item . PHP_EOL . "</a>";
                scanDirRecursively2($fullPath); // Llamada recursiva
            } 
        }
    }

    // Comenzar a escanear desde la carpeta raíz
    scanDirRecursively2($folderPath);
}

function parseFolderAndFiles($folderPath) {
    if (!is_dir($folderPath)) {
        //die("La carpeta no existe: $folderPath");
    }

    // Función auxiliar para escanear carpetas de forma recursiva
    function scanDirRecursively($path) {
        $items = scandir($path);
        foreach ($items as $item) {
            // Omitir los punteros de directorio actuales y padres
            if ($item === '.' || $item === '..') {
                continue;
            }

            $fullPath = $path . DIRECTORY_SEPARATOR . $item;
            if (is_dir($fullPath)) {
                echo "<h3 id='".$fullPath."'>" . $item . PHP_EOL . "</h3>";
                scanDirRecursively($fullPath); // Llamada recursiva
            } elseif (is_file($fullPath)) {
                $extensiones = ['py','php'];
                $explotado = explode(".",$item);
                $extension = explode(".",$item)[count($explotado)-1];
            	
                echo "<strong>" . $item . PHP_EOL. "</strong><br>";
                $content = file_get_contents($fullPath);
                if($extension == "py"){
                    echo "<pre>" . nl2br($content) .  PHP_EOL . "</pre>"; 
                } else {
                    echo "<p>" . nl2br($content) .  PHP_EOL . "</p>"; 
                }
            }
        }
    }

    // Comenzar a escanear desde la carpeta raíz
    scanDirRecursively($folderPath);
}

// Ejemplo de uso
$folderPath = __DIR__; // Esto usará la carpeta raíz del proyecto donde está index.php
creaIndice($folderPath);
parseFolderAndFiles($folderPath);
?>
