from funciones import *
"""
    Aplicación de Mascotas

"""

bienvenida()
while True:
    menu()
    opcion = input("Selecciona una opción(1-4):")
    print(f"Has escogido la opcion: {opcion}")
    if opcion == "1":
        insertar()
    elif opcion == "2":
        listar()
    elif opcion == "3":
        actualizar()
    elif opcion == "4":
        eliminar()
    elif opcion == "5":
        guardar()
    elif opcion == "6":
        cargar()
    elif opcion == "7":
        salir()