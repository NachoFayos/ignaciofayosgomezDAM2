window.onload = function(){
    console.log("Javascript cargado");
    document.querySelector("#login").onclick = function(){
        login()
    }
    document.onkeypress = function(e){
    	console.log("Has pulsado una tecla")
    	if(e.code == "Enter"){
    		console.log("Y la tecla es enter")
    		login()
    	}
    }
    
}


function login(){
	console.log("Has pulsado el boton");
	  let usuario = document.querySelector("#usuario").value;
	  let contrasena = document.querySelector("#contrasena").value;
	  console.log(usuario,contrasena);
	  
	  let mensaje = {"usuario":usuario,"contrasena":contrasena}      // Enviamos la información json en POST
	  fetch("../servidor/?o=buscar&tabla=usuarios", {
		                 method: 'POST', 
		                 headers: {
		                   'Content-Type': 'application/json', 
		                 },
		                 body: JSON.stringify(mensaje),  
		               })
	  .then(response => {
		 return response.json();                                                       
	  })
	  .then(data => {
		 
		 console.log( data);                                            
		 if(data.length > 0){                                               
		   console.log("Entras correctamente")
		   localStorage.setItem('bat1_usuario', data[0].usuario);       
		   localStorage.setItem('bat1_token',data[0].token)
		   document.querySelector("#feedback").style.color = "green"         
		   document.querySelector("#feedback").innerHTML = "Acceso correcto. Redirigiendo en 2 segundos...";   
		   setTimeout(function(){
		       window.location = "escritorio/index.html";                                             
		   },2000)
		 }else{
		   console.log("Error al entrar")
		   document.querySelector("#feedback").style.color = "red"           
		   document.querySelector("#feedback").innerHTML = "Usuario incorrecto. Redirigiendo en 2 segundos...";        
		   setTimeout(function(){
		       //window.location = window.location;                              
		   },2000)
		 }
		 
	  })
	  .catch(error => {
	  		document.querySelector("#toast").classList.add("animado")
        document.querySelector("#toast").textContent = "Error n.02 - Contacta con administrador"
        console.warn("Error:", error);
        
    });
}