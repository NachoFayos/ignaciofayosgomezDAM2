<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['table']) && isset($_POST['format'])) {
    $tableHTML = base64_decode($_POST['table']);                                                   // Decodifica la tabla enviada
    $format = $_POST['format'];                                                                    // Obtiene el formato seleccionado


////////////////////////////////// DESCARGA DE FORMATOS //////////////////////////////////

    switch ($format) {  
        case 'html':  //Formato HTML
            header('Content-Type: text/html');
            header('Content-Disposition: attachment; filename="table.html"');
            echo "<!DOCTYPE html>";
            echo "<html><head><title>Downloaded Table</title></head><body>";
            echo $tableHTML;
            echo "</body></html>";
            break;

        case 'csv':  //Formato CSV
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="table.csv"');
            $dom = new DOMDocument();
            @$dom->loadHTML($tableHTML);
            $rows = $dom->getElementsByTagName('tr');
            $output = fopen('php://output', 'w');

            foreach ($rows as $row) {
                $csvRow = [];
                foreach ($row->getElementsByTagName('td') as $cell) {
                    $csvRow[] = trim($cell->textContent);
                }
                fputcsv($output, $csvRow);
            }
            fclose($output);
            break;

        case 'json':  //Formato JSON
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="table.json"');
            $dom = new DOMDocument();
            @$dom->loadHTML($tableHTML);
            $rows = $dom->getElementsByTagName('tr');
            $jsonArray = [];

            foreach ($rows as $row) {
                $rowArray = [];
                foreach ($row->getElementsByTagName('td') as $cell) {
                    $rowArray[] = trim($cell->textContent);
                }
                if (!empty($rowArray)) {
                    $jsonArray[] = $rowArray;
                }
            }
            echo json_encode($jsonArray, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

            break;

        default:
            echo "Formato no válido";
            break;
    }
    exit;
}
?>
