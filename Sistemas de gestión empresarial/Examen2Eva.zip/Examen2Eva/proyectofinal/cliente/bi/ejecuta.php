<style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
        background-color:rgb(181, 210, 243);
        border-top-left-radius: 80px 80px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        background-color: #ffffff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    th, td {
        padding: 12px;
        text-align: left;
        border: 1px solid #ddd;
    }
    th {
        background-color: #4A90E2;
        color: white;
        text-transform: capitalize;
    }
    tr:nth-child(even) {
        background-color: rgba(220, 223, 252, 0.973);
    }
    tr:hover {
        background-color: #f2f2f2;
    }
    .row-number {
        font-weight: bold;
        text-align: center;
    }
</style>


<?php
////////////// CONEXION A LA BASE DE DATOS ////////////////
$host = "localhost";
$username = "bat1";
$password = "bat1";
$database = "bat1";

$conn = new mysqli($host, $username, $password, $database);
$conn->set_charset("utf8mb4"); 

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = $_GET['sql'];      // SQL query //


$result = $conn->query($sql);     // Ejecuta la query //

              //////////// GENERAR TABLA ////////////
function generateTableHTML($result) {
    if ($result && $result->num_rows > 0) {
        $html = "<table border='1'>";
        
        
        $html .= "<tr><th>#</th>";
        $columns = $result->fetch_fields();
        foreach ($columns as $column) {
            $html .= "<th>" . htmlspecialchars($column->name) . "</th>";
        }
        $html .= "</tr>";
        

        $rowNumber = 1;
        while ($row = $result->fetch_assoc()) {
            $html .= "<tr>";
            $html .= "<td>" . $rowNumber++ . "</td>";
            foreach ($row as $value) {
                $html .= "<td>" . htmlspecialchars($value) . "</td>";
            }
            $html .= "</tr>";
        }
        
        $html .= "</table>";
        return $html;
    } else {
        return "No results found.";
    }
}


$tableHTML = generateTableHTML($result);


echo $tableHTML;


if ($result && $result->num_rows > 0) {      // Generador de link de descarga //
    $encodedTableHTML = base64_encode($tableHTML);
    echo "<form method='post' action='download.php'>";
echo "<input type='hidden' name='table' value='" . $encodedTableHTML . "'>";
echo "<select name='format'>
         <option value='html'>HTML</option>
         <option value='csv'>CSV</option>
         <option value='json'>JSON</option>
      </select>";
echo "<button type='submit'>Download</button>";
echo "</form>";

}

$conn->close();
?>