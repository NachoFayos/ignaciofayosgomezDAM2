window.onload = function(){
	

    let usuario = localStorage.getItem("bat1_usuario")       // Declaramos usuario
    if(usuario == undefined){
    	window.location = "../"
    }
    let token =  localStorage.getItem("bat1_token")          // Declaramos token
    if(token == undefined){
    	window.location = "../"
    }
    
    fetch("../../servidor/?o=compruebatoken&token="+token) 
    .then(response => {
          return response.json();                       
        })
        .then(data => {
        	//console.log(data)
        	if(data.resultado){
        		
        	}else{
        		//window.location = "../"
        	}
        })
    
    fetch("../../servidor/?o=listadodeaplicacionesusuario&usuario="+usuario)         // Lista aplicaciones
        .then(response => {
          return response.json();                       
        })
        .then(data => {
            const plantilla = document.getElementById('plantilla_aplicacion');              // Template de la planilla de aplicaciones
            //console.log(data)                                                               
            data.forEach(function(elemento) {                                               // Para cada uno de los elementos que vienen en el json de la base de datos
                console.log(elemento);                                                      
                const instancia = plantilla.content.cloneNode(true);                        // Creacion de la instancia 
                const nombre = instancia.querySelector('p');                                // Seleccion del elemento
                nombre.innerHTML = elemento.nombre;                                         // Y le pongo el contenido que saco del json
                let icono = instancia.querySelector(".icono")
                icono.textContent = elemento.nombre[0]
                document.querySelector('main').appendChild(instancia);                      
            });
            
            let aplicaciones = document.querySelectorAll(".aplicacion")                     // Seleccion de todas las aplicaciones
            aplicaciones.forEach(function(aplicacion){                                      
                aplicacion.onclick = function(){                                            
                    localStorage.setItem('bat1_aplicacion', this.querySelector("p").textContent);
                    localStorage.setItem('bat1_departamento', "NombreDelDepartamento");
                    window.location = "../escritorio2/"
                }
            })
        })
     document.querySelector("#cerrarsesion").onclick = function(){   // Cerrar sesión
     	localStorage.removeItem("bat1_usuario")
     		localStorage.removeItem("bat1_token")
     		window.location = "../"
     }
}