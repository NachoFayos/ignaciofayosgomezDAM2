window.onload = function(){ 
	
///////////// EXACTAMENTE LO MISMO QUE LAS APLICACIONES PERO CON LOS DEPARTAMENTOS //////////////////

    let usuario = localStorage.getItem("bat1_usuario")
    if(usuario == undefined){
    	window.location = "../"
    }
    let token =  localStorage.getItem("bat1_token")
    if(token == undefined){
    	window.location = "../"
    }
    
    fetch("../../servidor/?o=compruebatoken&token="+token) 
    .then(response => {
          return response.json();                       
        })
        .then(data => {
        	console.log(data)
        	if(data.resultado == "ok"){
        		
        	}else{
        		//window.location = "../"
        	}
        })
    
        let aplicacion = localStorage.getItem("bat1_aplicacion");

        if (!aplicacion) {  
            console.error(" No se encontró 'bat1_aplicacion' en localStorage.");
            window.location = "../escritorio1/";       // Redirige si no hay aplicación seleccionada
            return;
        }
        console.log("Aplicación seleccionada:", aplicacion);

        fetch("../../servidor/?o=obtenerdepartamentoporaplicacion&aplicacion=" + aplicacion)
        .then(response => {
            return response.json();                       
          })
          .then(data => {
              const plantilla = document.getElementById('plantilla_departamento');              
              console.log(data)                                                               
              data.forEach(function(elemento) {                                               
                  console.log("Departamento:", elemento);                                                      
                  const instancia = plantilla.content.cloneNode(true);                        
                  const nombre = instancia.querySelector('p');                                
                  nombre.innerHTML = elemento.nombre;    
                  let icono = instancia.querySelector(".icono")                                     
                  icono.textContent = elemento.nombre[0]
                  document.querySelector('main').appendChild(instancia);                      
              });

            let departamentos = document.querySelectorAll(".departamento")                     
            departamentos.forEach(function(departamento){                                      
                departamento.onclick = function(){                                            
                    localStorage.setItem('bat1_departamento', this.querySelector("p").textContent);
                    window.location = "../supercontrolador/"
                }
            })
        })
     document.querySelector("#cerrarsesion").onclick = function(){
     	localStorage.removeItem("bat1_usuario")
     		localStorage.removeItem("bat1_token")
     		window.location = "../"
     }
}