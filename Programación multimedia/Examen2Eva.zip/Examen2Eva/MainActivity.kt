package com.nachofg.calculadorahipotecaria

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etMonto = findViewById<EditText>(R.id.etMonto)
        val etTasa = findViewById<EditText>(R.id.etTasa)
        val etPlazo = findViewById<EditText>(R.id.etPlazo)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)

        // Agregar '%' automáticamente en etTasa
        etTasa.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (!s.isNullOrEmpty() && !s.toString().endsWith("%")) {
                    etTasa.removeTextChangedListener(this) // Evita bucles infinitos
                    etTasa.setText("${s.toString().replace("%", "")}%") // Agrega %
                    etTasa.setSelection(etTasa.text.length - 1) // Mueve el cursor antes del %
                    etTasa.addTextChangedListener(this) // Vuelve a agregar el listener
                }
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnCalcular.setOnClickListener {
            val monto = etMonto.text.toString().toDoubleOrNull() ?: 0.0
            val tasaTexto = etTasa.text.toString().replace("%", "").toDoubleOrNull() ?: 0.0
            val tasa = (tasaTexto / 100) / 12
            val plazo = (etPlazo.text.toString().toIntOrNull() ?: 0) * 12

            if (monto > 0 && tasa >= 0.0001 && plazo > 0) {
                val cuota = (monto * tasa * (1 + tasa).pow(plazo)) / ((1 + tasa).pow(plazo) - 1)
                tvResultado.text = "Cuota mensual: %.2f".format(cuota)
            } else {
                tvResultado.text = "Por favor, ingrese valores válidos"
            }
        }
    }
}
