const API_URL = "http://localhost:3000";

// Inicializar gráficos con Chart.js
const ctxCPU = document.getElementById("cpuChart").getContext("2d");
const ctxRAM = document.getElementById("ramChart").getContext("2d");
const ctxDisk = document.getElementById("diskChart").getContext("2d");
const ctxNetwork = document.getElementById("networkChart").getContext("2d");

const cpuChart = new Chart(ctxCPU, {
    type: "line",
    data: { labels: [], datasets: [{ label: "CPU (%)", data: [], borderColor: "red" }] }
});

const ramChart = new Chart(ctxRAM, {
    type: "line",
    data: { labels: [], datasets: [{ label: "RAM (GB)", data: [], borderColor: "blue" }] }
});

const diskChart = new Chart(ctxDisk, {
    type: "line",
    data: { labels: [], datasets: [{ label: "Disco (%)", data: [], borderColor: "green" }] }
});

const networkChart = new Chart(ctxNetwork, {
    type: "line",
    data: { labels: [], datasets: [{ label: "Red (KB/s)", data: [], borderColor: "purple" }] }
});


function updateCharts() {                  // Función para actualizar gráficos en tiempo real
    fetchData("/cpu", cpuChart);
    fetchData("/ram", ramChart);
    fetchData("/disk", diskChart);
    fetchData("/network", networkChart);
    setTimeout(updateCharts, 2000);
}


function fetchData(endpoint, chart) {      // Función para obtener datos y actualizar gráficos
    fetch(`${API_URL}${endpoint}`)
        .then(response => response.json())
        .then(data => {
            const time = new Date().toLocaleTimeString();
            chart.data.labels.push(time);
            chart.data.datasets[0].data.push(data.usage || data.used || data.percent || data.upload);
            chart.update();
        });
}


function fetchText(url, elementId, formatter) {         // Función para obtener texto y actualizar la interfaz
    fetch(`${API_URL}${url}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById(elementId).innerText = formatter(data);
        });
}


function fetchTable(url, tableId) {                     // Función para actualizar la tabla de procesos pesados
    fetch(`${API_URL}${url}`)
        .then(response => response.json())
        .then(data => {                                 // Recogemos los datos
            console.log(" Datos recibidos para la tabla:", data); 

            const table = document.getElementById(tableId);
            if (!table) {
                console.error(" Error: No se encontró el elemento de la tabla.");
                return;
            }

            table.innerHTML = "<tr><th>PID</th><th>Nombre</th><th>CPU</th><th>RAM</th></tr>"; 

            if (!Array.isArray(data) || data.length === 0) {
                console.log(" No hay datos disponibles");
                table.innerHTML += "<tr><td colspan='4'>No hay datos disponibles</td></tr>";
                return;
            }

            data.forEach(p => {
                console.log(` Agregando proceso PID: ${p.pid}, Nombre: ${p.name}`);
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${p.pid}</td>
                    <td>${p.name}</td>
                    <td>${p.cpu}%</td>
                    <td>${p.ram}%</td>
                `;
                table.appendChild(row);
            });

            console.log(" Tabla actualizada correctamente.");
        })
        .catch(error => console.error(" Error al cargar la tabla:", error));
}


function updateData() {          //  Función para actualizar datos generales 
    fetchText("/cpu", "cpu-info", data => `Uso: ${data.usage}%`);
    fetchText("/ram", "ram-info", data => `Usada: ${data.used}GB`);
    fetchText("/disk", "disk-info", data => `Ocupado: ${data.percent}%`);
    fetchText("/network", "network-info", data => `Subida: ${data.upload} KB/s`);
    fetchText("/connections", "connections-info", data => `Activas: ${data.activeConnections}`);
    fetchText("/battery", "battery-info", data => `Nivel: ${data.percent}% (${data.charging})`);

    fetchTable("/processes", "procesos");          //  Llamamos a fetchTable() para actualizar la tabla

    setTimeout(updateData, 3000);
}

// Función para exportar datos (JSON o CSV)
function exportData(type) {
    window.location.href = API_URL + "/export/" + type;
}

// Función para mostrar pestañas
function showTab(tab) {
    document.querySelectorAll(".tab").forEach(e => e.style.display = "none");
    document.getElementById(tab).style.display = "block";
}

// Iniciar actualización automática de datos y gráficos
updateData();
updateCharts();
showTab("inicio");
