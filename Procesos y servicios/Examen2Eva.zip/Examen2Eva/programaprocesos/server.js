const express = require("express");
const cors = require("cors");
const fs = require("fs");
const si = require("systeminformation");

const app = express();
app.use(cors());

let dataHistory = { cpu: [], ram: [], network: [], disk: [], battery: [] };


app.get("/cpu", async (req, res) => {      // Obtener uso de CPU
    const cpu = await si.currentLoad();
    const usage = cpu.currentLoad.toFixed(2);
    
    // Guardar en historial
    dataHistory.cpu.push({ time: new Date().toISOString(), usage });

    res.json({ usage });
});


app.get("/ram", async (req, res) => {        // Obtener RAM
    const mem = await si.mem();
    const used = ((mem.used) / 1024 ** 3).toFixed(2);
    
    // Guardar en historial
    dataHistory.ram.push({ time: new Date().toISOString(), used });

    res.json({ used });
});


app.get("/network", async (req, res) => {         // Obtener Red
    const net = await si.networkStats();
    const upload = (net[0].tx_sec / 1024).toFixed(2);
    const download = (net[0].rx_sec / 1024).toFixed(2);
    
    // Guardar en historial
    dataHistory.network.push({ time: new Date().toISOString(), upload, download });

    res.json({ upload, download });
});


app.get("/disk", async (req, res) => {           // Obtener Disco
    const disk = await si.fsSize();
    const total = (disk[0].size / 1024 ** 3).toFixed(2);
    const used = (disk[0].used / 1024 ** 3).toFixed(2);
    const percent = ((disk[0].used / disk[0].size) * 100).toFixed(2);

    
    dataHistory.disk.push({ time: new Date().toISOString(), used });       // Guardamos el historial del disco

    res.json({ total, used, percent });
});


app.get("/connections", async (req, res) => {          // Obtener Conexiones Activas
    const netConnections = await si.networkConnections();
    res.json({ activeConnections: netConnections.length });
});


app.get("/battery", async (req, res) => {         // Obtener Estado de Batería
    const battery = await si.battery();
    
    
    dataHistory.battery.push({ time: new Date().toISOString(), percent: battery.percent });   // Guardamos el historial de la bateria

    res.json({
        percent: battery.percent,
        charging: battery.isCharging ? "Conectado" : "No conectado"
    });
});


app.get("/processes", async (req, res) => {       // Obtener Procesos Pesados
    const processes = await si.processes();
    const topProcesses = processes.list
        .sort((a, b) => b.cpu - a.cpu)
        .slice(0, 5)
        .map(p => ({ pid: p.pid, name: p.name, cpu: p.cpu.toFixed(2), ram: p.mem.toFixed(2) }));

    res.json(topProcesses);
});


app.get("/export/json", (req, res) => {         // Exportación a JSON
    fs.writeFileSync("data.json", JSON.stringify(dataHistory, null, 2));
    res.download("data.json");
});


app.get("/export/csv", (req, res) => {       // Exportación a CSV
    let csv = "time,metric,value\n";
    
    Object.entries(dataHistory).forEach(([metric, values]) => {
        values.forEach(entry => {
            csv += `${entry.time},${metric},${entry.usage || entry.used || entry.upload || entry.download || entry.percent}\n`;
        });
    });

    fs.writeFileSync("data.csv", csv);
    res.download("data.csv");
});

// Iniciar servidor
app.listen(3000, () => console.log("Servidor en http://localhost:3000"));
