from flask import Flask, render_template, request
import random
import mysql.connector
import plotly.graph_objects as go
import plotly.io as pio                              # Librería para la conversión de JSON

app = Flask(__name__)

################ CONEXIÓN BASE DE DATOS ################
MYSQL_HOST = "localhost"
MYSQL_USER = "sankey"
MYSQL_PASSWORD = "sankey"
MYSQL_PORT = 3306

def get_databases():
    """Obtiene las bases de datos en MySQL y maneja errores."""
    try:
        conn = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            port=MYSQL_PORT
        )
        cursor = conn.cursor()
        cursor.execute("SHOW DATABASES;")
        databases = [db[0] for db in cursor.fetchall()]
        conn.close()
        print(f"Bases de datos encontradas: {databases}")  #f para insertar el valor de la variable err dinamicamente en el mensaje de error
        return databases
    except mysql.connector.Error as err:
        print(f"Error conectando a MySQL: {err}") 
        return []

################ CONEXIÓN BASE DE DATOS ################


################ OBTENER CLAVES FORANEAS ################

def get_foreign_keys(database):
    """Obtiene las relaciones de claves foráneas en la base de datos seleccionada."""
    conn = mysql.connector.connect(host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD, database=database, port=MYSQL_PORT)
    cursor = conn.cursor()

    query = """
    SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = %s AND REFERENCED_TABLE_NAME IS NOT NULL;
    """
    
    cursor.execute(query, (database,))
    relations = cursor.fetchall()
    conn.close()

    
    labels = []                             # Parte donde se construye el Sankey
    label_index = {}
    links = {"source": [], "target": [], "value": [], "color": []}
    node_colors = []

 ################ OBTENER CLAVES FORANEAS ################   


 ################ GENERAR COLORES ALEATORIOS ################  
    
    def random_rgba():
        return f"rgba({random.randint(50, 200)}, {random.randint(50, 200)}, {random.randint(50, 200)}, 0.8)"

    for table, col, ref_table, ref_col in relations:
        for node in [table, ref_table]:
            if node not in label_index:
                label_index[node] = len(labels)
                labels.append(node)
                node_colors.append(random_rgba())               # cOLOREO los nodos

        links["source"].append(label_index[ref_table])
        links["target"].append(label_index[table])
        links["value"].append(1)
        links["color"].append(random_rgba())                    # Coloreo cada enlace

################ GENERAR COLORES ALEATORIOS ################       
        
    
################ CREACIÓN DEL GRÁFICO ################

    sankey_figure = go.Figure(go.Sankey(
        node=dict(
            pad=15,
            thickness=20,
            label=labels,
            color=node_colors  # Aplica los colores a los nodos
        ),
        link=dict(
            source=links["source"],
            target=links["target"],
            value=links["value"],
            color=links["color"]  # Aplica los colores a los enlaces
        )
    ))

################ CREACIÓN DEL GRÁFICO ################


################ CONVERSION DEL GRAFICO A JSON ################
    
    graph_json = pio.to_json(sankey_figure)
    return graph_json

################ CONVERSION DEL GRAFICO A JSON ################

@app.route("/")
def index():
    """Página principal con el selector de bases de datos."""
    databases = get_databases()
    return render_template("index.html", databases=databases)

@app.route("/sankey", methods=["POST"])
def sankey():
    """Muestra el diagrama Sankey de la base de datos seleccionada."""
    database = request.form["database"]
    sankey_graph = get_foreign_keys(database)
    return render_template("sankey.html", database=database, sankey_graph=sankey_graph)

if __name__ == "__main__":
    app.run(debug=True, port=5001)
