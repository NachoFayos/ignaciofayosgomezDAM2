
################ COMPROBACIÓN DE LA CONEXIÓN SQL ################

import mysql.connector

try:
    conn = mysql.connector.connect(
        host="localhost",
        user="sankey",
        password="sankey",
        port=3306
    )
    print("Conexión exitosa a MySQL")
    conn.close()
except mysql.connector.Error as err:
    print(f"Error conectando a MySQL: {err}")

################ COMPROBACIÓN DE LA CONEXIÓN SQL ################