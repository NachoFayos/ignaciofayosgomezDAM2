<?php
	
	/* 
		Archivo que incluyo los módulos del programa
	*/
	
	include "./modulos/cabeza/cabeza.php";
	include "./modulos/cabecera/cabecera.php";
	include "./modulos/principal/principal.php";
	include "./modulos/piedepagina/piedepagina.php";
	include "./modulos/modal/modal.php";
	include "./modulos/librerias/librerias.php";
	include "./modulos/cierre/cierre.php";
	
?>
    