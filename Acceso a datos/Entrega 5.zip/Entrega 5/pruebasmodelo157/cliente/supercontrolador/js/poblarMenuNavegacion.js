function poblarMenuNavegacion(datos, tipoentidad) {
    console.log("Datos recibidos:", datos);
    console.log("tipo de entidad recibida:" , tipoentidad);
    //console.log("Tipo de datos:", typeof datos, Array.isArray(datos));

    // Verificar si `datos` tiene contenido antes de procesarlo
    if (!datos || datos === "false" || datos.length === 0) {
        console.error(" ERROR: datos es inválido o está vacío:", datos);
        return;
    }

    // Convertir a array si es un objeto y no un array
    if (!Array.isArray(datos)) {
        console.warn(" Datos no era un array, convirtiéndolo...");
        datos = Object.values(datos);
    }

    //console.log("Antes de forEach, datos es:", datos);
    //console.log("¿Es array?", Array.isArray(datos));
    //console.log("Longitud de datos:", datos.length);

    if (!Array.isArray(datos) || datos.length === 0) {
        console.error(" ERROR: datos sigue vacío después de la conversión:", datos);
        return;
    }

    let menu = document.querySelector("nav #" + tipoentidad);
    let nombre_de_la_tabla;
    datos.forEach(tabla => {
        //console.log("Iterando sobre:", tabla);
        ///Detecta el tipo de coleccion si es tabla es tables... y si es coleccion se deja como esta///
        if (tipoentidad == "tabla"){
            console.log("Estas en sql:", tabla)
            nombre_de_la_tabla = tabla['Nombre_Tabla']; 
        }
        else{
            nombre_de_la_tabla = tabla['Tables_in_bat1'];
        }  
        let elemento = document.createElement("li");         
        let icono;
console.log(tabla);
        switch(tipoentidad){
            case "tabla":
                icono = "<span class='boton botonblanco'>📁</span>";
                break;
            case "coleccion":
                icono = "<span class='boton botonblanco'>📃</span>";
        }
        console.log("te digo el nombre de la tabla" ,nombre_de_la_tabla);
        elemento.innerHTML = icono + " " + nombre_de_la_tabla;  
        elemento.setAttribute("destino", nombre_de_la_tabla);
        elemento.setAttribute("jvtooltip", "Haz click para cargar la información de la tabla " + nombre_de_la_tabla);
        elemento.setAttribute("comentario", tabla['Comentario']);

        elemento.onclick = function() {  
            let texto = this.getAttribute("destino");  
            switch(tipoentidad){
                case "tabla":
                    cargaDatosTabla(texto);
                    break;
                case "coleccion":
                    cargaDatosColeccion(texto);
                    console.log("ok coleccion");
                    console.log(texto);
            }

            document.querySelector(".titulotabla h5").textContent = this.textContent;
            //document.querySelector(".titulotabla p").textContent = this.getAttribute("comentario");

            let elementosmenu = document.querySelectorAll("nav ul li");
            elementosmenu.forEach(function(elemento){    
                elemento.classList.remove("menuseleccionado");
            });

            this.classList.add("menuseleccionado");
        };

        menu.appendChild(elemento);
    });
}
