<main>
      <?php include "modulos/navegacion/navegacion.php"; ?>
      <?php include "modulos/seccionprincipal/seccionprincipal.php"; ?>
    </main>
 <script><?php echo file_get_contents("modulos/principal/principal.js");?></script>
<style><?php echo file_get_contents("modulos/principal/principal.css");?></style>   
    
    