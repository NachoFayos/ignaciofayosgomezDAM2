
    document.addEventListener("DOMContentLoaded", function () {
    // Crear el botón flotante
    let botontop = document.createElement("button");
    botontop.innerHTML = "⬆";
    botontop.classList.add("botontop");
    document.body.appendChild(botontop);

    // Ocultar el botón al principio
    botontop.style.display = "none";

    // Mostrar el botón cuando el usuario baja
    window.addEventListener("scroll", function () {
        if (window.scrollY > 300) {
            botontop.style.display = "block";
        } else {
            botontop.style.display = "none";
        }
    });

    // Evento de clic para subir al inicio
    botontop.addEventListener("click", function () {
        window.scrollTo({
            top: 0,
            behavior: "smooth" // Desplazamiento suave
        });
    });
});

