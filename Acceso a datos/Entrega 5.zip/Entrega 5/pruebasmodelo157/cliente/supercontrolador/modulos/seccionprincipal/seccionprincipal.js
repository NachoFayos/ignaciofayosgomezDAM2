function cargaGraficas(){
	fetch("../../servidor/?o=estadisticastablas")
    	.then(function(result){
    		return result.json()
    	})
    	.then(function(datos){
    	//console.log("Servidor Preparado para trabajar")
    		let nuevografico = new JVGrafica(datos,"#dc146c","table tbody","Resgistros en cada tabla");
			nuevografico.anillo()
    	})
}

function cargoDepartamentos(){
	////////////////////////////////// CARGO LAS APPSSSSSS /////////////////////////////////////////////
    
    fetch("../supercontrolador/apps/apps.json")
    .then(function(response){
    	return response.json()
    })
    .then(function(datos){
    	console.log("estoy en :" .datos)
    	departamentos = datos
    })
}
function muestraBI(){
	//// BUSINESS ANALYTICS ////
	
	document.querySelector("#businessanalytics").onclick = function(){
		console.log("Has entrado en Business Analytics")
		document.querySelector("section").innerHTML = ""
		let marco = document.createElement("iframe")
		marco.setAttribute("src","../bi/")
		document.querySelector("section").appendChild(marco)
	}
}