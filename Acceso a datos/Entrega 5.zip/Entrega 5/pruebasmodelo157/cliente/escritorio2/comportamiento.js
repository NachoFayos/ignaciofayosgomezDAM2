window.onload = function(){
	

    let usuario = localStorage.getItem("bat1_usuario")
    if(usuario == undefined){
    	window.location = "../"
    }
    let token =  localStorage.getItem("bat1_token")
    if(token == undefined){
    	window.location = "../"
    }
    
    fetch("../../servidor/?o=compruebatoken&token="+token) 
    .then(response => {
          return response.json();                       // Quiero que el servidor me devuelva un json
        })
        .then(data => {
        	console.log(data)
        	if(data.resultado == "ok"){
        		
        	}else{
        		//window.location = "../"
        	}
        })
    
        let aplicacion = localStorage.getItem("bat1_aplicacion");

        if (!aplicacion) {  
            console.error(" No se encontró 'bat1_aplicacion' en localStorage.");
            window.location = "../escritorio1/"; // Redirige si no hay aplicación seleccionada
            return;
        }
        console.log("Aplicación seleccionada:", aplicacion);

        fetch("../../servidor/?o=obtenerdepartamentoporaplicacion&aplicacion=" + aplicacion)
        .then(response => {
            return response.json();                       // Quiero que el servidor me devuelva un json
          })
          .then(data => {
              const plantilla = document.getElementById('plantilla_departamento');              // Cargo el template HTML como una plantilla en memoria (como un class)
              console.log(data)                                                               // Vomito el json en pantalla
              data.forEach(function(elemento) {                                               // Para cada uno de los elementos que vienen en el json de la base de datos
                  console.log("Departamento:", elemento);                                                      // Pongo el elemento en pantalla simplemente para comprobar que funciona
                  const instancia = plantilla.content.cloneNode(true);                        // Creo  una nueva instancia de la clase (como un instance)
                  const nombre = instancia.querySelector('p');                                // Dentro de la plantilla selecciono a uno de los elementos
                  nombre.innerHTML = elemento.nombre;                                         // Y le pongo el contenido que saco del json
                  let icono = instancia.querySelector(".icono")
                  icono.textContent = elemento.nombre[0]
                  document.querySelector('main').appendChild(instancia);                      // Por ultimo realmente pongo la instancia en el arbol html
              });

            let departamentos = document.querySelectorAll(".departamento")                     // Selecciono todas las aplicaciones y las pongo en un array
            departamentos.forEach(function(departamento){                                      // Para cada una de las aplicaciones
                departamento.onclick = function(){                                            // Cuando haga click en esa aplicacion
                    localStorage.setItem('bat1_departamento', this.querySelector("p").textContent);
                    window.location = "../supercontrolador/"
                }
            })
        })
     document.querySelector("#cerrarsesion").onclick = function(){
     	localStorage.removeItem("bat1_usuario")
     		localStorage.removeItem("bat1_token")
     		window.location = "../"
     }
}