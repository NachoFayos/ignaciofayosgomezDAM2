<?php

	echo $_SERVER['SERVER_ADDR'];
	
?>